# Arkaes Tokens Usage Notes

## Suggested monorepo location

```txt
arkaes/
  apps/
    portfolio/
  packages/
    tokens/
  packages/
    ui/
```

## Recommended dependency direction

```txt
apps/portfolio -> packages/ui -> packages/tokens
apps/portfolio -> packages/tokens
```

The portfolio app can import global token CSS directly.

The UI package should rely on CSS variables and should not duplicate primitive values.

## Token philosophy

Use primitive tokens for raw values:

```css
--ark-color-blush-500
--ark-space-6
--ark-radius-xl
```

Use semantic tokens for component styling:

```css
--ark-color-bg
--ark-color-surface
--ark-color-text
--ark-color-accent
--ark-color-border
```

In components, prefer semantic tokens.

Good:

```css
background: var(--ark-color-surface);
color: var(--ark-color-text);
```

Avoid:

```css
background: var(--ark-color-blush-100);
color: var(--ark-color-neutral-900);
```

Raw primitive tokens are still useful for illustrations, gradients, charts, and brand-specific visuals.

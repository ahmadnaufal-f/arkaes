export const radius = {
  xs: "0.375rem",
  sm: "0.5rem",
  md: "0.875rem",
  lg: "1.25rem",
  xl: "1.75rem",
  "2xl": "2.25rem",
  full: "999px",
} as const;

export type ArkaesRadiusScale = typeof radius;

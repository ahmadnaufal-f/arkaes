export const colors = {
  blush: {
    50: "#fff8f6",
    100: "#f7e8e3",
    200: "#e9c8be",
    300: "#d7a79b",
    400: "#bd8276",
    500: "#9d6359",
    600: "#784a43",
  },
  sage: {
    50: "#f7f8f3",
    100: "#e8eadf",
    200: "#cdd3bc",
    300: "#aeb997",
    400: "#8e9d75",
    500: "#6f7f58",
    600: "#566244",
  },
  warm: {
    50: "#fbf7f1",
    100: "#f3eadf",
    200: "#dfcdbc",
    300: "#c5ab98",
    400: "#a78976",
    500: "#836a5b",
    600: "#5f4c42",
  },
  neutral: {
    0: "#ffffff",
    50: "#faf9f7",
    100: "#f1eee9",
    200: "#ddd7cf",
    300: "#c3b9ad",
    400: "#9d9185",
    500: "#7a6f65",
    600: "#5e554d",
    700: "#463f39",
    800: "#302b27",
    900: "#1f1b18",
  },
} as const;

export type ArkaesColorScale = typeof colors;

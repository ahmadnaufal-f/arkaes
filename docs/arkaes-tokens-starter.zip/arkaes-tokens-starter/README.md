# @arkaes/tokens

Design tokens starter package for the Arkaes portfolio and UI system.

This package contains:

- CSS custom properties for runtime styling
- TypeScript token exports for tooling and documentation
- light/dark semantic theme tokens
- base reset and typography utility classes

## Install in the workspace

In the monorepo root:

```bash
pnpm add @arkaes/tokens --filter portfolio --workspace
```

## Use in Astro

Import the CSS entry once in your Astro app.

```astro
---
import "@arkaes/tokens/css";
---
```

Or import from your main stylesheet:

```css
@import "@arkaes/tokens/css";
```

## Use in Lit components

Lit components can consume the same CSS variables.

```ts
import { LitElement, css, html } from "lit";

export class ArkCard extends LitElement {
  static styles = css`
    :host {
      display: block;
    }

    article {
      border: 1px solid var(--ark-color-border);
      border-radius: var(--ark-radius-xl);
      background: var(--ark-color-surface);
      color: var(--ark-color-text);
      box-shadow: var(--ark-shadow-sm);
      padding: var(--ark-space-6);
    }
  `;

  render() {
    return html`
      <article>
        <slot></slot>
      </article>
    `;
  }
}
```

## Theme switching

Set `data-theme="dark"` on the root HTML element.

```ts
document.documentElement.dataset.theme = "dark";
```

Remove it or set `data-theme="light"` for the default light theme.

## Naming convention

All CSS variables use the `--ark-*` prefix.

Recommended component naming:

```html
<ark-button></ark-button>
<ark-card></ark-card>
<ark-badge></ark-badge>
```

Package name:

```txt
@arkaes/tokens
```

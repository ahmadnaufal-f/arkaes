export { typography } from "./tokens/typography";
export type { ArkaesTypographyScale } from "./tokens/typography";
